Supermicro Update Manager (for UEFI BIOS) 1.3.0-p6 (2023/09/05) (UEFI)

Introduction
  The Supermicro Update Manager (SUM) UEFI can be used to manage the system
  BIOS, BMC and CPLD firmware image update for X12/H12 and later platforms
  except H12 non-RoT systems under EFI shell.
  To update DMI information, users can edit DMI information from readable text
  file, as well as use SUM to apply DMI information.

The package includes:
  - SUM.efi
  - README.txt
  - ReleaseNote.txt

==============================================================================================================================

SYNOPSIS
  SUM.efi [OPTIONs] [COMMAND] [COMMAND ARGUMENTS]

Help Message
  SUM.efi (Shows help information)
  SUM.efi -h/H (Shows help information)
  SUM.efi -h/H -c <Command name> (Shows help information for each command)

OPTIONs
  -I        Redfish_HI
  -u        <BMC user ID>
  -p        <BMC user password>
  -c        <Command name>

COMMANDS
  UpdateBios, GetBiosInfo, BiosRotManage, UpdateBmc, GetBmcInfo, BmcRotManage, RawCommand, UpdateCpld, GetCpldInfo
 , GetDmiInfo, ChangeDmiInfo, EditDmiInfo

COMMAND ARGUMENTS
  Required and optional arguments of each commands. 
  For detail information of each command, please refer to section below.

==============================================================================================================================
UpdateBios command:

Description
  Updates BIOS.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c UpdateBios --file BIOS.rom --reboot [Optional Arguments]

Required Arguments
  --file        BIOS image file

Optional Arguments
  --reboot                Forces the managed system to reboot or power up after operation
  --flash_smbios          Overwrites the SMBIOS data
  --preserve_nv           Preserves the NVRAM region
  --preserve_mer          Preserves the ME firmware region
  --backup                Backups current running BIOS image. (Only support for RoT systems)
  --forward               Confirms the Rollback ID forward
  --erase_OA_key          Erases OA key. (Only support for in-band usage)
  --clear_password        Clears BIOS password.
  --erase_secure_boot_key Erases secure boot key.
  --reset_boot_option     Resets BIOS boot configurations.
  --preserve_setting      Preserves BIOS configurations.
  --staged
      Sets action to:
	    1 = update : Update process will start on the next system boot.
	    2 = abort : Abort the previously staged update task.
      3 = getinfo : Check if whether there was any pending staged update task.            

Node Product Key Required
  No

Note: --flash_smbios and --preserve_nv optional arguments cannot be used at the same time.
Note: --erase_OA_key, --clear_password, --erase_secure_boot_key, --reset_boot_option and --preserve_setting only support on 
      Tatlow and later platforms.

==============================================================================================================================

UpdateBmc command:

Description
  Updates BMC.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c UpdateBmc --file BMC.rom [Optional Arguments]

Required Arguments
  --file    BMC image file

Optional Arguments
  --overwrite_cfg        Overwrites the current BMC configuration using the factory default values in the given BMC image file
  --overwrite_sdr        Overwrites current BMC SDR data
  --overwrite_ssl        Overwrites current BMC SSL configuration.
  --backup               Backups current running BMC image. (Only support for RoT systems)
  --forward              Confirms the Rollback ID forward

Node Product Key Required
  No

==============================================================================================================================

GetBiosInfo command:

Description
  Gets system BIOS information of the managed system.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetBiosInfo
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetBiosInfo --file BIOS.rom
  SUM.efi -c GetBiosInfo --file BIOS.rom --file_only

Required Arguments
  N/A

Optional Arguments
  --file             Reads BIOS information from an input BIOS image file
  --file_only        Works with --file, and only reads BIOS information from the input image file
  --showall          Prints the capsule information.

Node Product Key Required
  No

==============================================================================================================================

GetBmcInfo command:

Description
  Gets system BMC information of the managed system.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetBmcInfo 
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetBmcInfo --file BMC.rom
  SUM.efi -c GetBmcInfo --file BMC.rom --file_only

Required Arguments
  N/A

Optional Arguments
  --file             Reads BMC information from an input BMC image file
  --file_only        Works with --file, and only reads BMC information from the input image file

Node Product Key Required
  No

==============================================================================================================================

BiosRotManage command:

Description
  Execute RoT relate actions.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c BiosRotManage --action UpdateGolden

Required Arguments
  --action
      Sets action to:
	    1 = GetInfo
	    2 = UpdateGolden
	    3 = Recover

Optional Arguments
  --reboot
      Works with --action UpdateGolden and Recover. Forces the managed
      system to reboot or power up after operation.  

Node Product Key Required
  SFT-DCMS-SINGLE for action recover
  
Note: UpdateGolden action will overwrite golden image with current BIOS firmware.

==============================================================================================================================

BmcRotManage command:

Description
  Execute RoT related actions.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c BmcRotManage --action UpdateGolden

Required Arguments
  --action
      Sets action to:
	    1 = GetInfo
	    2 = UpdateGolden
	    3 = Recover

Optional Arguments
  N/A

Node Product Key Required
  SFT-DCMS-SINGLE for action recover
  
Note: UpdateGolden action will overwrite golden image with current BMC firmware.

==============================================================================================================================

RawCommand command:

Description
  Sends IPMI raw command.

Example
  SUM.efi -c RawCommand --raw "06 01"

Required Arguments
  --raw    <raw command>
    Inputs hex-value commands.

Optional Arguments
  N/A

Node Product Key Required
  No
    
Note: Raw command has to be quoted.

==============================================================================================================================

UpdateCpld command:

Description
  Updates CPLD.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c UpdateCpld --file CPLD.bin --reboot

Required Arguments
  --file             Updates the CPLD with the given CPLD image file.
  --reboot           Forces the managed system to reboot or power up after operation.

Optional Arguments
  N/A

Node Product Key Required
  No
  
Note: System needs to be powered off while updating CPLD FW.

==============================================================================================================================

GetCpldInfo command:

Description
  Gets the CPLD information of the managed system/input CPLD image file.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetCpldInfo
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetCpldInfo --file CPLD.bin
  SUM.efi -c GetCpldInfo --file CPLD.bin --file_only

Required Arguments
  N/A

Optional Arguments
  --file             Reads the CPLD information from an input CPLD image file.
  --file_only        Works with --file, and only reads CPLD information from the input image file.

Node Product Key Required
  No
  
==============================================================================================================================

GetDmiInfo command:

Description
  Gets the DMI information of the managed system.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetDmiInfo
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetDmiInfo --file dmi.txt
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c GetDmiInfo --file dmi.txt --overwrite

Required Arguments
  N/A

Optional Arguments
  --file             Saves the DMI information to a file.
  --overwrite        Overwrites the output file.

Node Product Key Required
  Yes
  
==============================================================================================================================

ChangeDmiInfo command:

Description
  Updates DMI information.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c ChangeDmiInfo --file dmi.txt
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c ChangeDmiInfo --file dmi.txt --reboot

Required Arguments
  --file             Updates the DMI information with the given text file.

Optional Arguments
  --reboot           Forces the managed system to reboot after operation

Node Product Key Required
  Yes
  
==============================================================================================================================

EditDmiInfo command:

Description
  Edits the given DMI information text file.

Example
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c EditDmiInfo --file dmi.txt --shn SYVS --value "1.02"
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c EditDmiInfo --file dmi.txt --item_type "System" --item_name "Version" --value "1.02"
  SUM.efi -I Redfish_HI -u ADMIN -p ADMIN -c EditDmiInfo --file dmi.txt --shn SYVS --default

Required Arguments
  --file    <file name>
      The DMI information file to be edited (or created if it does not exist).
  --item_type    <item type>
      Specifies the item type.
  --item_name    <item name>
      Specifies the item name.
  --shn    <short name>
      Specifies the item in short name format.
  --value    <assignment value>
      Assigns the value to the item.
  --default
      Assigns the default value to the item.
  Note:
        1. Either [--item_type, --item_name] or [--shn] is required.
        2. Either [--value] or [--default] is required.

Optional Arguments
  N/A

Node Product Key Required
  Yes
  
==============================================================================================================================
